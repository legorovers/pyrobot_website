import simclient.simrobot as initio

initio.init()

input = input(['Would you like a distance reading? [Y/N]'])

if (input == 'Y'):
    print(initio.getDistance())
