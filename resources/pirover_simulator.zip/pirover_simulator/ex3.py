import simclient.simrobot as initio, time
initio.init()
 
while (initio.getDistance() > 50):
   print("Waiting")
 
initio.setServo(0, 20)
time.sleep(1)
initio.setServo(0, 0)
